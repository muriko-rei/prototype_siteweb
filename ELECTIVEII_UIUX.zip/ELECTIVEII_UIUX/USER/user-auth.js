const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');
const showSignup = document.getElementById('showSignup');
const showLogin = document.getElementById('showLogin');

// Toggle forms
showSignup.onclick = () => {
    loginForm.classList.add('hidden');
    signupForm.classList.remove('hidden');
};

showLogin.onclick = () => {
    signupForm.classList.add('hidden');
    loginForm.classList.remove('hidden');
};

// Login
loginForm.addEventListener('submit', e => {
    e.preventDefault();

    const payload = {
        username: loginUsername.value,
        password: loginPassword.value
    };

    console.log("LOGIN READY:", payload);

    // After backend success → redirect
    window.location.href = "index.html";
});

// Signup
signupForm.addEventListener('submit', e => {
    e.preventDefault();

    const payload = {
        username: signupUsername.value,
        email: signupEmail.value,
        password: signupPassword.value
    };

    console.log("SIGNUP READY:", payload);

    // After backend success → redirect
    window.location.href = "index.html";
});
