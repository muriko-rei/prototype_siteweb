const reservationForm = document.getElementById("reservationForm");

reservationForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const amenities = Array.from(
        document.querySelectorAll('input[name="amenities[]"]:checked')
    ).map(a => a.value);

    const reservationData = {
        full_name: document.getElementById("full_name").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
        dob: document.getElementById("dob").value,
        age: document.getElementById("age").value,
        address: document.getElementById("address").value,
        room_type: document.getElementById("room_type").value,
        guests: document.getElementById("guests").value,
        amenities: amenities,
        payment: document.querySelector('input[name="payment"]:checked').value
    };

    console.log("READY FOR BACKEND INTEGRATION:", reservationData);

    showReceipt(reservationData);
});
