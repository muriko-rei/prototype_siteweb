const dobInput = document.getElementById("dob");
const ageInput = document.getElementById("age");
const form = document.getElementById("reservationForm");
const message = document.getElementById("message");

dobInput.addEventListener("change", function () {
    const dob = new Date(dobInput.value);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const monthDiff = today.getMonth() - dob.getMonth();

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
        age--;
    }

    ageInput.value = age;
});

form.addEventListener("submit", function (e) {
    e.preventDefault();

    if (ageInput.value === "" || ageInput.value < 18) {
        message.textContent = "Guest must be at least 18 years old.";
        message.style.color = "red";
        return;
    }

    message.textContent = "Reservation form validated successfully.";
    message.style.color = "green";
});
