
const mainContent = document.querySelector('.main-content');

document.querySelectorAll('[data-section]').forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault();

        const sectionId = link.getAttribute('data-section');
        const section = document.getElementById(sectionId);

        if (!section) return;

        // Calculate scroll position relative to main-content
        const topPos = section.offsetTop;

        // Smooth scroll INSIDE main-content
        mainContent.scrollTo({
            top: topPos - 20,
            behavior: 'smooth'
        });

        // Zoom indicator
        section.classList.remove('zoom-indicator');
        void section.offsetWidth;
        section.classList.add('zoom-indicator');

        // Fix active state (sidebar + top nav)
        document.querySelectorAll('.sidebar-nav a, .top-nav nav a')
            .forEach(a => a.classList.remove('active'));

        document.querySelectorAll(`[data-section="${sectionId}"]`)
            .forEach(a => a.classList.add('active'));
    });
});


const tableBody = document.querySelector('#reservationTable tbody');
const fetchButton = document.getElementById('fetchDataBtn');
const searchInput = document.getElementById('searchInput');

// ---------------------- Fetch Reservations ----------------------
async function fetchReservations() {
    try {
        // Replace with your backend API URL
        const response = await fetch('your-backend-api-url/reservations');
        const data = await response.json();

        // Clear table
        tableBody.innerHTML = '';

        // Update summary cards if provided by backend
        if(data.summary){
            document.getElementById('totalReservations').innerText = data.summary.total || 0;
            document.getElementById('pendingReservations').innerText = data.summary.pending || 0;
            document.getElementById('confirmedReservations').innerText = data.summary.confirmed || 0;
        }

        // Populate table
        data.reservations.forEach(reservation => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${reservation.id}</td>
                <td>${reservation.guest_name}</td>
                <td>${reservation.room_type}</td>
                <td>${reservation.check_in}</td>
                <td>${reservation.guests}</td>
                <td><span class="status ${reservation.status.toLowerCase()}">${reservation.status}</span></td>
                <td>
                    <button class="action-btn view-btn" data-id="${reservation.id}">View</button>
                    <button class="action-btn update-btn" data-id="${reservation.id}">Update</button>
                    <button class="action-btn delete-btn" data-id="${reservation.id}">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });

    } catch (error) {
        console.error('Error fetching reservations:', error);
        alert('Failed to fetch reservations. Check backend.');
    }
}

// ---------------------- Search Filter ----------------------
function filterTable() {
    const query = searchInput.value.toLowerCase();
    const rows = tableBody.querySelectorAll('tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const match = Array.from(cells).some(cell =>
            cell.textContent.toLowerCase().includes(query)
        );
        row.style.display = match ? '' : 'none';
    });
}

// ---------------------- Update Reservation ----------------------
async function updateReservation(id) {
    // Placeholder: open modal or prompt to edit fields
    const newStatus = prompt("Enter new status (confirmed/pending/cancelled):");
    if (!newStatus) return;

    try {
        // Replace with your backend update URL
        const response = await fetch(`your-backend-api-url/reservations/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: newStatus })
        });

        if(response.ok){
            alert(`Reservation ${id} updated successfully!`);
            fetchReservations(); // refresh table
        } else {
            alert('Failed to update reservation.');
        }
    } catch(error){
        console.error('Update error:', error);
        alert('Error updating reservation.');
    }
}

// ---------------------- Delete Reservation ----------------------
async function deleteReservation(id) {
    const confirmDelete = confirm(`Are you sure you want to delete reservation ${id}?`);
    if(!confirmDelete) return;

    try {
        // Replace with your backend delete URL
        const response = await fetch(`your-backend-api-url/reservations/${id}`, {
            method: 'DELETE'
        });

        if(response.ok){
            alert(`Reservation ${id} deleted successfully!`);
            fetchReservations(); // refresh table
        } else {
            alert('Failed to delete reservation.');
        }
    } catch(error){
        console.error('Delete error:', error);
        alert('Error deleting reservation.');
    }
}

// ---------------------- Event Listeners ----------------------
fetchButton.addEventListener('click', fetchReservations);
searchInput.addEventListener('input', filterTable);

// Delegate Update/Delete buttons dynamically
tableBody.addEventListener('click', (e) => {
    if(e.target.classList.contains('update-btn')){
        const id = e.target.dataset.id;
        updateReservation(id);
    }
    if(e.target.classList.contains('delete-btn')){
        const id = e.target.dataset.id;
        deleteReservation(id);
    }
});


// Check-in table elements
const checkinTableBody = document.querySelector('#checkinTable tbody');
const fetchCheckinBtn = document.getElementById('fetchCheckinBtn');
const checkinSearchInput = document.getElementById('checkinSearchInput');

// Function to fetch check-in data from backend
async function fetchCheckins() {
    try {
        // Replace with backend API endpoint
        const response = await fetch('your-backend-checkin-api-url');
        const data = await response.json();

        // Clear existing rows
        checkinTableBody.innerHTML = '';

        // Populate table
        data.forEach(guest => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${guest.id}</td>
                <td>${guest.guest_name}</td>
                <td>${guest.room_type}</td>
                <td>${guest.check_in}</td>
                <td>${guest.guests}</td>
                <td><span class="status checkedin">Checked-in</span></td>
                <td>
                    <button class="action-btn update-btn">Update</button>
                    <button class="action-btn checkout-btn">Check-out</button>
                </td>
            `;
            checkinTableBody.appendChild(row);
        });
    } catch (error) {
        console.error('Error fetching check-in data:', error);
        alert('Failed to fetch check-in data. Please check backend connection.');
    }
}

// Search filter for check-in table
function filterCheckinTable() {
    const query = checkinSearchInput.value.toLowerCase();
    const rows = checkinTableBody.querySelectorAll('tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const match = Array.from(cells).some(cell =>
            cell.textContent.toLowerCase().includes(query)
        );
        row.style.display = match ? '' : 'none';
    });
}

// Event listeners
fetchCheckinBtn.addEventListener('click', fetchCheckins);
checkinSearchInput.addEventListener('input', filterCheckinTable);


// Handle sidebar + top nav clicks
document.querySelectorAll('[data-section]').forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault();

        const sectionId = link.getAttribute('data-section');
        const section = document.getElementById(sectionId);

        if (!section) return;

        // Smooth scroll to section
        section.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });

        // Zoom indicator animation
        section.classList.remove('zoom-indicator');
        void section.offsetWidth; // restart animation
        section.classList.add('zoom-indicator');

        // Update active state (sidebar + top nav)
        document.querySelectorAll('.sidebar-nav a, .top-nav nav a')
            .forEach(a => a.classList.remove('active'));

        document.querySelectorAll(`[data-section="${sectionId}"]`)
            .forEach(a => a.classList.add('active'));
    });
});
